advancement revoke @s only unbreakables:item_changed

execute if items entity @s weapon.* *[minecraft:damage] run item modify entity @s weapon.mainhand unbreakables:make_unbreakable
execute if items entity @s weapon.* *[minecraft:damage] run item modify entity @s weapon.offhand unbreakables:make_unbreakable

execute if items entity @s armor.* *[minecraft:damage] run item modify entity @s armor.feet unbreakables:make_unbreakable
execute if items entity @s armor.* *[minecraft:damage] run item modify entity @s armor.legs unbreakables:make_unbreakable
execute if items entity @s armor.* *[minecraft:damage] run item modify entity @s armor.chest unbreakables:make_unbreakable
execute if items entity @s armor.* *[minecraft:damage] run item modify entity @s armor.head unbreakables:make_unbreakable
